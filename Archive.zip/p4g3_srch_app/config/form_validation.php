<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config = array(
               
   'create' => array(                  
               
                      
                  array(
                     'field'   => 'string', 
                     'rules'   => 'required'
                  ) 
               )
               
            );
            