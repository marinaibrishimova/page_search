<!DOCTYPE html>
<head>
<title>Search Tab App</title>

<head>
	<meta charset="utf-8">         
        <meta property="og:title" content="Search Tab App" />
        <meta property="og:image" content="images/earth.jpg" /> 
        <meta property="og:url" content="https://ibrius.com/post-finder/" />
    
        <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>	
	<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.8.21/jquery-ui.min.js" type="text/javascript" charset="utf-8"></script>
	 
  
  <link rel="stylesheet" href="<?php echo base_url(); ?>css/stylegri.css" type="text/css" media="all">
  <link rel="stylesheet" href="<?php echo base_url(); ?>css/tooltip.css" type="text/css" media="all">
   
   
</head>
<body id="backend">
 
  <div id="wrapper">
  
   <div id="free">
	<div class="up">
	<p>  
        <a href="https://facebook.com/ibrius" target="_blank"><?php echo $this->lang->line('common_developed_by');?> Ibrius</a>
        </p>
        </div>
        </div>
        <div class="clear"></div>
   </div> 