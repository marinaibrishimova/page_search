<?php 

$this->load->view('partial/header'); ?>

<p style="font-size:16px; color:#777;"><?php echo $error; ?></p>

<?php $this->load->view('partial/footer'); ?>